It is web app created to search for movie in a particular theathre and so to enhance the service this is done .
